import data_treatment
import boxplot
import dbscan
import numpy as np
import k_means
import statistic_significance
import feature_extractor as fe
import feature_selection as fs
import zscore as z
from config import DEBUG
#Trabalho Realizado por:
  #Martim Alves Rodrigues da Costa Duarte nº 2021275991
  #Simão Tomás Botas Carvalho nº 2021223055

if DEBUG:
    print("DEBUG está ativo")

#usar estes arrays para chamar a função abaixo
#CUIDADO
all_participants = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14]
all_sensors = [1,2,3,4,5]

# 1 Get dados em np array
dados = data_treatment.get_data(all_participants,2) #type: ignore

if DEBUG:   
    print("Fim de get data")
  
# calcular o módulo dos sensores
modules = data_treatment.calculate_modules(dados[:, 1:10])

# 2. Extrair atividades (coluna 12)
activities = dados[:, 11].astype(int)  # índice 11 = coluna 12

# 3. Criar boxplots para cada sensor e detetar outliers
labels = ["Aceleração", "Giroscópio", "Magnetômetro"]

sensor_info = {
    label: modules[:, i]
    for i, label in enumerate(labels)
}

"""for label, data in sensor_info.items():
    boxplot.create_boxplot_per_activity(data, activities, label)


# 3.4 Outliers por sensor e atividade usando o z score
k_values = [3,3.5,4]
z.plot_outliers_zScore(sensor_info, activities, k_values)
"""


# Para k-means e dbscan
atividades_selecionadas = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16] #mudar aqui o número da atividade a ver, também aceita array
modules_normalizados = data_treatment.normalize_range(modules,0,1)

"""


# 3.6 K-means manual por atividade

k = 4  # número de clusters
modules_filtrados, clusters, centroids, distances, labels_filtrados = k_means.k_means_manual(
    data=modules_normalizados,
    labels=activities,
    atividades=atividades_selecionadas,
    k=k
)

outliers = k_means.detect_outliers_kmeans(distances, threshold_std=2)


if k_means.DEBUG:
    print(f"Encontrados {np.sum(outliers)} outliers com k={k} nas atividades {atividades_selecionadas}")

# Imprimir densidade de outliers por atividade (semelhante ao boxplot)
k_means.print_outlier_density_per_activity(
    labels_filtrados,
    outliers,
    atividades=atividades_selecionadas,
)

# 3.7 Plot 3D K-means por atividade
k_means.plot_kmeans_results_3d(
    data=modules_filtrados,
    clusters=clusters,
    centroids=centroids,
    outliers=outliers,
    labels=labels_filtrados,
    atividades=atividades_selecionadas,
)

k_means.plot_kmeans_outliers(distances,labels_filtrados,outliers)



#3.7.1 Dbscan (bónus)
eps = 0.04

dbscan_data, dbscan_clusters, dbscan_labels = dbscan.dbscan_cluster(modules_normalizados,activities,atividades_selecionadas,eps)

dbscan.plot_dbscan_results_3d(dbscan_data,dbscan_clusters,dbscan_labels,atividades_selecionadas)

dbscan.plot_dbscan_outliers(dbscan_data,dbscan_clusters,dbscan_labels)

"""

# 4.1 Análise de significância estatística
# F (ANOVA) = diferenças de MÉDIAS (maior = mais diferente)
# H (Kruskal) = diferenças de DISTRIBUIÇÕES (maior = mais diferente)
# p < 0.05 = significativo


modules_normalizados = data_treatment.normalize_range(modules)

statistic_significance.analyze_statistical_significance(modules_normalizados, activities)


# 4.2 Extração de features temporais e espectrais

# Preparar dados dos sensores
accel_data = dados[:, 1:4].astype(float)  # Colunas 2-4
gyro_data = dados[:, 4:7].astype(float)   # Colunas 5-7
mag_data = dados[:, 7:10].astype(float)   # Colunas 8-10

sr = fe.sampling_rate_calculator(dados)

# Executar extração de features
X_features, y_labels, window_info = fe.extract_features_4_2(
    accel_data, gyro_data, mag_data, activities, sampling_rate=sr
)

# Verificar primeiras features
if len(X_features) > 0:
    print(f"\nPrimeira janela - {X_features.shape[1]} features:")
    print(f"Labels: {y_labels[:10]}...")  # Primeiros 10 labels
    
    # Salvar features para usar nos próximos pontos
    np.savetxt('features_X.csv', X_features, delimiter=',', fmt='%.6f')
    np.savetxt('features_y.csv', y_labels, delimiter=',', fmt='%d')
    print("Features guardadas em 'features_X.csv' e 'features_y.csv'")
    with open('features_info.txt', 'w') as f:
      f.write(f"Total janelas: {X_features.shape[0]}\n")
      f.write(f"Total features por janela: {X_features.shape[1]}\n")
      f.write(f"Sampling rate: {sr} Hz\n")
      f.write(f"Window size: {5 * sr} amostras\n")
    
    print("Metadados guardados em 'features_info.txt'")



# 4.3 Análise PCA
X_features = np.loadtxt('features_X.csv', delimiter=',')
X_pca, pca_model, scaler = fe.pca_analysis(X_features, target_variance=0.75)

#Guardar resultados PCA
np.savetxt('features_X_pca.csv', X_pca, delimiter=',', fmt='%.6f')
print("Features PCA guardadas em 'features_X_pca.csv'")


#4.5
# Fisher
top10_fisher, fisher_scores = fs.fisher_score_selection(X_features, y_labels, top_n=10)

# ReliefF
top10_relief, relief_scores = fs.reliefF_selection(X_features, y_labels, top_n=10, n_neighbors=10)


# 4.6
# Reconstruir vetor de nomes das features com base numa janela de exemplo
try:
    print("\nA reconstruir nomes das features...")
    window_size = 5 * sr
    accel_win = accel_data[:window_size]
    gyro_win = gyro_data[:window_size]
    mag_win = mag_data[:window_size]

    feat_dict = fe.FeatureExtractor.extract_window_features(accel_win, gyro_win, mag_win, sampling_rate=sr)
    feature_names = list(feat_dict.keys())
    print(f"Foram identificadas {len(feature_names)} features nomeadas.")

except Exception as e:
    print(f"Aviso: não foi possível reconstruir nomes reais das features ({e})")
    feature_names = [f"f{i}" for i in range(X_features.shape[1])]
    print("Usados nomes genéricos f0, f1, f2, ...")


# Comparar resultados
common = set(top10_fisher).intersection(set(top10_relief))

if common:
    print(f"Features em comum entre Fisher e ReliefF: {(common)}")
else:
    print("Não existem features em comum entre Fisher e ReliefF.")

# === 4.6.1 - OBTENÇÃO E EXEMPLO DAS FEATURES SELECIONADAS ===
print("\n=== 4.6.1 - Features relativas à seleção ===")

X_fisher = X_features[:, top10_fisher]
X_relief = X_features[:, top10_relief]

instante = 0
print(f"\nInstante de exemplo: {instante}")
print(f"Atividade associada: {int(y_labels[instante])}")

print("\n--- Features selecionadas por Fisher ---")
for i, idx in enumerate(top10_fisher):
    nome = feature_names[idx] if idx < len(feature_names) else f"f{idx}"
    valor = X_fisher[instante, i]
    print(f"{i+1:2d}. {nome:40s}  valor = {valor:.6f}")

print("\n--- Features selecionadas por ReliefF ---")
for i, idx in enumerate(top10_relief):
    nome = feature_names[idx] if idx < len(feature_names) else f"f{idx}"
    valor = X_relief[instante, i]
    print(f"{i+1:2d}. {nome:40s}  valor = {valor:.6f}")